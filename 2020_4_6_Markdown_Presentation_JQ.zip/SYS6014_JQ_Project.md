﻿<div align="center"> <img src="C:\\Users\jamie\Documents\SYS6014\Project\uvalogo.png" align="middle" style="height: 124px"/>

## <span style="color:blue"><div align="center">TO BUY OR NOT TO BUY?
## <span style="color:blue"><div align="center">USING A LONG SHORT-TERM MEMORY (LSTM)
## <span style="color:blue"><div align="center">NETWORK TO DRIVE BITCOIN PURCHASES 
## <span style="color:blue"><div align="center">PROJECT  
## <span style="color:blue"><div align="center">FOR UNIVERSITY OF VIRGINIA 
## <span style="color:blue"><div align="center">SPRING 2020
## <span style="color:blue"><div align="center">SYS 6014 DECISION ANALYSIS
## <span style="color:blue"><div align="center">JAMIE QUINTANA
## <span style="color:blue"><div align="center">April 6th, 2020

<div style='page-break-after: always'></div>
<div align="left">

## TABLE OF CONTENTS
* INTRODUCTION
* DECISION PROBLEM
* PREDICTIVE MODEL
* PRIOR BELIEFS
* DECISION MATRIX (not part of presentation)
* RESULTS *(partial results included)*
* CONCLUSION (when finalized)
* REFERENCES 


***Key Words:*** Bitcoins, binomial distribution, Bayesian analysis, decision making, classification, machine learning, Auto regression 

***Reproducible Research:*** to create report, use Matlab 2019b or higher with all toolboxes, run live notebook 03_25_2020_SYS-6014_Project_Proposal_Final.mlx. Prerequisite files needed 2020_3_14_OPEN.csv, 2020_3_14_CLOSE.csv,  Y_Feb.mat, P_vector.mat, and Jan_Key.mat. 

<div style='page-break-after: always'></div>

## INTRODUCTION

  * Use of the word “bitcoin” was virtually non-existent until ~2008.
  * First appeared in a white paper titled Bitcoin: A Peer-to-Peer Electronic Cash System credited to Satoshi Nakamotox on October 31st, 2008.
 * On Dec 1st, 2014 bitcoin to dollar equivalency was $370 
 * Today, one bitcoin equals ~$6,000 to $9,000 
 * Most transactions are fractions of bitcoins
 * Example - $500 of bitcoins bought on Feb 19th 2020  
     * Worth only $471 dollars on Feb 20th
     * a ~$29 loss in value
 * Project concerned with best or optimal time to buy Bitcoins - price goes up or down 
 
To establish a baseline, the binomial distribution can be used to examine the probabilities of events occurring based on some properties of the random variable. 
* the random variable is the state of the bitcoin price going up or down

 
<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig1.png">

<div align="left">

Here - 
* **d** is the number of days
* **N** is the number of trials
* **P** is the probability of success (i.e. **p** = .5)
* **k** is the desired number of successes

* Plot below considers next 30 days
* 50-50 chance of going up or down
* Probability of randomly guessing price will go
up (i.e. be a success) for 15 of those 30 days, the probability equals ~43% 

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig2.png">

As shown in the plot, the probability of getting 15 predictions correct increases significantly to 90% when the
probability of success is increased to .63

**Goal of this project is to increase the rate of probability to determine the next "success" to some probability > .5.**

## DECISION PROBLEM

For this project, the max budget **B** is set at **$5,000**. Goal is to maximize in expectation the
total number of successful purchase days.
* where the decision maker has to make **ten** purchases each **@ $500** of bitcoins during the month of February
  +
 ### Actions  - No.  Description 

1. ------------------------> Do not buy bitcoins 
2. ------------------------> Buy bitcoins without using model data 
3. ------------------------> Buy bitcoins on Mondays 
4. ------------------------> Buy bitcoins on Tuesdays 
5. ------------------------> Buy bitcoins on Wednesdays 
6. ------------------------> Buy bitcoins on Thursdays 
7. ------------------------> Buy bitcoins on Fridays 
8. ------------------------> Buy bitcoins on Saturdays 
9. ------------------------> Buy bitcoins on Sundays 
10. ------------------------> Buy bitcoins based on price prediction forecast (next day prediction: up or down)

**Note*** the context for ***"next day"*** hence forward in this paper is the day immediately following the model's last known Open and Close values. 
* The predicted day is the current day's opening price for which the closing price is still unknown.

The **success criteria** for the project is simple.
* **Goal**  - use the model's prediction capabilities
to either break even (no loss) or make a positive gain
* Project will be viewed as a *failure if the end results
culminate in a loss*.

## PREDICTION MODEL

The model for this project has two major steps: ***Baseline and Working***

Auto regression is a specific time series technique that examines data from previous time steps (i.e. previous set of days) as inputs
to forecast or predict the next day value

Like auto regression, a long short-term memory (LSTM) network can be used to forecast the time series data

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig3.png">

Model is first tuned to minimize error components while maximizing accuracy. 

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig5.png">

The variable **days** are set for the forecast windows and **Fdays** are days to skip - allowing the sliding window to move along dates without adjusting any other model parameters. 

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig4.png">

For the working model step, with **days** set to **5**, where **y** is the opening price at day **5**, and **x** is the predicted price at
day **i**
* if resulting value is equal to or greater than one (i.e. positive), then =1

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig6.png">

* similarly, **x** is the predicted price at day **5**, and **y** is the observed price at day **i**

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig7.png">

When both **CDP1 **and** CDP2 = 1**, the probability increases that next day's price will be up (i.e. set to 1). All other combinations results in 0 (i.e. price should go down).  Sixth day **Key = 1**. Otherwise, set to **0**.

For the entire month of February, using the working model to slide the 5-day window across February, a Prediction Key will be generated one-execution run at a time. (i.e. 1101001101100011001010010101000111)

Since the data for February is known, we can use a bootstrap method of create a probability distribution for the average daily loss or gains

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig9.png">

Plot shows the average gain for the month is about -$1.4 - again, purchasing $500 at opening and compared to closing.

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig10.png">

The plot here shows the distribution for February but randomly selecting 10 days at a time and summing - gain or loss.
Here - the mean gain/loss is for 10 purchases is ~-$14 

## PRIOR BELIEFS

I think most people (i.e. decision makers) believe there is no real, consistent, reliable way to determine when is the best time to make a purchase 

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig8.png">

* As seen in the plot , price changes from one day to the next seem erratic
* Over the short term, the patterns in the data may appear to follow trends either upward or downward


## RESULTS

After 27 iterations of executing the working model, (only changing FDays), the full prediction vector can be examined for accuracy and Up Probability 

The Up Probability is determine by comparing how many times the model was correct when it predicted price would go Up. 

In this case, the model achieved an accuracy of 77% and an up probability of 83% from Jan 5th to Jan 31th. 

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig11.png">
Plots show that for the period of Jan 5th to Jan 31th the mean gain was ~$4.

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig13.png">

When summing the 12 days the model predicted price would go up, the total gain/loss equals ~$144

<img src="C:\\Users\jamie\Documents\SYS6014\Project\Fig12.png">

When comparing the model's success against the probability of randomly selecting 12 other days (over 100,000 times), the model's achievement is significant.

## REFERENCES

* Berger, James O. Statistical Decision Theory and Bayesian Analysis, 2nd ed. Springer, 1993. ISBN: 978-0387960982.
* Hoff, Peter D. A First Course in Bayesian Statistical Methods. Springer, 2009. ISBN: 978-0387922997.24
* Nakamoto, Satoshi (31 October 2008). "Bitcoin: A Peer-to-Peer Electronic Cash System" (PDF). bitcoin.org.
* Small, A. III (2020, February 3). 2020-02-03_Decision_Analyis_slides. Retrieved February 29,
2020, from https://github.com/UVA-Engineering-Decision-Analysis/course-materials/blob/master/ slides/2020-02-03_Decision_Analyis_slides.pdf
* Small, A, III, Stefik, B, Jason, Verlinde, Johannes, Johnson, C, Nathaniel. "The Cloud Hunter’s Problem: An Automated Decision Algorithm to Improve the Productivity of Scientific Data Collection in Stochastic Environments." MONTHLY WEATHER REVIEW vol 139, pp. 2276-2289, Dec. 2010
* Vigna, Paul; Casey, Michael J. (January 2015). The Age of Cryptocurrency: How Bitcoin and Digital Money Are
* Challenging the Global Economic Order (1 ed.). New York: St. Martin's Press. ISBN 978-1-250-06563-6.25